<div class="row empty">مالی > بدهی من</div>
<div class="cat">
    <div class="card my_card">
        <table class="table table-hover">
            <tr>
                <td class="td_title">نام دوره</td>
                <td class="font-weight-bold">مسافرت جنوب(1403/03/01)</td>
            </tr>
            <tr>
                <td class="td_title">خرج کرد</td>
                <td class="font-weight-bold">2,000,000 <span class="unit">ريال</span></td>
            </tr>
            <tr>
                <td class="td_title">سهم من</td>
                <td class="font-weight-bold">1,200,000 <span class="unit">ريال</span></td>
            </tr>
            <tr>
                <td class="td_title">پرداخت شده</td>
                <td class="font-weight-bold">200,000 <span class="unit">ريال</span></td>
            </tr>
            <tr class="bg-primary">
                <td class="td_title text-white">مانده</td>
                <td class="mande text-white font-weight-bold">1,000,000 <span class="unit">ريال</span></td>
            </tr>
        </table>
        <div class="pay_btn">
            <div class="pay_btn_icon">
                <?php echo $wallet;?>
            </div>
        </div>
    </div>
</div>