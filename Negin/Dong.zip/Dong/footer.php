<?php include_once('javascript.php'); ?>
</body>
</html>