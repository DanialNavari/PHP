<div class="rapid_access">
    <div class="item_" onclick="page('d','.')">
        <div class="item_circle bg_purple">
            <div class="item_icon"><?php echo $home; ?></div>
        </div>
        <div class="item_title">خانه</div>
    </div>
    <div class="item_">
        <div class="item_circle bg_green">
            <div class="item_icon"><?php echo $wallet; ?></div>
        </div>
        <div class="item_title">کیف پول</div>
    </div>
    <div class="item_">
        <div class="item_circle bg_gray">
            <div class="item_icon"><?php echo $contacts; ?></div>
        </div>
        <div class="item_title">مخاطبین</div>
    </div>
    <div class="item_">
        <div class="item_circle bg_orange">
            <div class="item_icon"><?php echo $active_course; ?></div>
        </div>
        <div class="item_title">دوره جدید</div>
    </div>
    <div class="item_">
        <div class="item_circle bg_blue">
            <div class="item_icon"><?php echo $bag_plus; ?></div>
        </div>
        <div class="item_title">خرید جدید</div>
    </div>
</div>

</div><!-- end of container -->
<?php include_once('javascript.php'); ?>

</body>

</html>