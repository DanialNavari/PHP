<!DOCTYPE html>
<html lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main.css" />
    <title>دنگ و دونگ</title>
</head>

<body>
    <div class="header text-right pr-3">
        <i><?php echo $hamburger_menu; ?></i>
        <h1 class="px-3 d-inline-block">دنگ و دونگ</h1>
    </div>
    <div class="container">
        