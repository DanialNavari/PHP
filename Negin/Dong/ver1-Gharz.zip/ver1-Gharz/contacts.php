<button onclick="openContactPicker()">Open my phone contacts</button>

<script>

</script>