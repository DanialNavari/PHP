<script>
    window.location.assign("https://cafebazaar.ir/app/co.median.android.qmqddn");
</script>