<tr>
    <td class="td_title w-9">میانگین هزینه هر نفر</td>
    <td class="font-weight-bold text-center">' . sep3($average_cost) . ' <span class="unit">' . $c_money_unit . '</span></td>
    <td class="font-weight-bold text-center"></td>
</tr>
<tr>
    <td class="td_title">تعداد تراکنش</td>
    <td class="font-weight-bold text-center">' . $x . '</td>
    <td class="font-weight-bold text-center"></td>
</tr>
<tr>
    <td class="td_title">مانده بدهی افراد دوره</td>
    <td class="font-weight-bold text-center">' . sep3($remain_cost) . ' <span class="unit">' . $c_money_unit . '</span></td>
    <td class="font-weight-bold text-center"></td>
</tr>
<tr>
    <td class="td_title">واریزی افراد دوره</td>
    <td class="font-weight-bold text-center">' . sep3($sum_all_pay) . ' <span class="unit">' . $c_money_unit . '</span></td>
    <td class="font-weight-bold text-center"></td>
</tr>