<?php
// Dongeto.com
// function db()
// {
//     $db_host = 'localhost';
//     $db_username = 'dongetoc_dongeto';
//     $db_password = 'KCZhgh54nKuegWsVvY8Q';
//     $db_name = 'dongetoc_dongeto';
//     date_default_timezone_set('Asia/Tehran');
//     $GLOBALS['conn'] = mysqli_connect($db_host, $db_username, $db_password, $db_name);
//     mysqli_set_charset($GLOBALS['conn'], "utf8");
// }

function db()
{
    $db_host = 'localhost';
    $db_username = 'root';
    $db_password = '';
    $db_name = 'dong';
    date_default_timezone_set('Asia/Tehran');
    $GLOBALS['conn'] = mysqli_connect($db_host, $db_username, $db_password, $db_name);
    mysqli_set_charset($GLOBALS['conn'], "utf8");
}
