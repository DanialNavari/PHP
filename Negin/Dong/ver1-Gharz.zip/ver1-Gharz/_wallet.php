<div class="row empty">کیف پول</div>
<div class="cat">
    <div class="card my_card">
        <table class="table">
            <tr>
                <td class="td_title">موجودی</td>
                <td class="font-weight-bold">0 <span class="unit">ريال</span></td>
                <td class="font-weight-bold"></td>
            </tr>
            <tr>
                <td class="td_title">بدهی به دوره ها</td>
                <td class="font-weight-bold">2,000,000 <span class="unit">ريال</span></td>
                <td class="font-weight-bold"></td>
            </tr>
            <tr>
                <td class="td_title_"></td>
                <td class="font-weight-bold"></td>
                <td class="font-weight-bold"></td>
            </tr>
            <tr>
                <td class="td_title_ "></td>
                <td class="font-weight-bold"></td>
                <td class="font-weight-bold"></td>
            </tr>
            <tr class="bg_dark_blue">
                <td class="td_title va_middle text-white wallet_charge">مبلغ شارژ کیف پول <span class="unit">(ريال)</span></td>
                <td class="font-weight-bold text-white"><input type="number" class="form-control rounded-2 text-center text-primary" value="100000"></td>
                <td class="font-weight-bold"></td>
            </tr>
            <tr class="bg_green">
                <td class="td_title_ va_middle text-white text-center sum d-rtl click px_05" colspan="3"><?php echo $wallet; ?> پرداخت آنلاین</td>
            </tr>

        </table>
    </div>
</div>

<div class="cat mb-1">
    <div class="group_name">
        <h6 class="font-weight-bold">تراکنش ها</h6>
    </div>
</div>

<div class="cat">
    <div class="card my_card">
        <table class="table">
            <tr class="bg_dark_blue">
                <td class="td_title font-weight-bold text-white">شارژ کیف پول</td>
                <td class="td_title_ text-white text-"><span>1403/03/01</span><span>10:32:16</span></td>
            </tr>
            <tr>
                <td class="td_title font-weight-bold text-primary">مبلغ <span>(ريال)</span></td>
                <td class="td_title_ text-center">1,000,000</td>
            </tr>
            <tr>
                <td class="td_title font-weight-bold text-primary">کد پیگیری </td>
                <td class="td_title_ text-center">123456789</td>
            </tr>
            <tr>
                <td class="td_title font-weight-bold text-primary">بانک</td>
                <td class="td_title_ text-center">بلوبانک</td>
            </tr>
        </table>
    </div>
</div>
<div class="cat">
    <div class="card my_card">
        <table class="table">
            <tr class="bg_dark_blue">
                <td class="td_title font-weight-bold text-white">شارژ کیف پول</td>
                <td class="td_title_ text-white text-"><span>1403/03/01</span><span>10:32:16</span></td>
            </tr>
            <tr>
                <td class="td_title font-weight-bold text-primary">مبلغ <span>(ريال)</span></td>
                <td class="td_title_ text-center">1,000,000</td>
            </tr>
            <tr>
                <td class="td_title font-weight-bold text-primary">کد پیگیری </td>
                <td class="td_title_ text-center">123456789</td>
            </tr>
            <tr>
                <td class="td_title font-weight-bold text-primary">بانک</td>
                <td class="td_title_ text-center">بلوبانک</td>
            </tr>
        </table>
    </div>
</div>
