<div class="row empty">افراد > افراد طلبکار</div>
<div class="cat">
    <div class="card my_card">
        <table class="table table-hove">
            <tr class="bg_dark_blue">
                <td class="td_title text-white course_Title" colspan="1">نام دوره</td>
                <td class="font-weight-bold text-white" colspan="3">مسافرت جنوب <span>(1403/03/01)</span></td>
            </tr>
            <tr>
                <td class="td_title td_title_">نام افراد</td>
                <td class="td_title_ text-center">سهم</td>
                <td class="td_title_ text-center">طلب (ريال)</td>
                <td class="td_title_ text-center">تسویه</td>
            </tr>
            <tr class="bg_grey">
                <td class="td_title">دانیال نواری</td>
                <td class="td_title_ text-center">1,000,000</td>
                <td class="td_title_ text-center">200,000</td>
                <td class="td_title_ text-center"><span class="tasviye_btn text-danger"><?php echo $check2; ?></span></td>
            </tr>
            <tr class="bg_dark_blue font-weight-bold">
                <td class="td_title_ text-white va_middle" colspan="1">جمع کل<span> (ريال)</span></td>
                <td class="td_title_ text-white text-center sum va_middle" colspan="1">1,000,000</td>
                <td class="td_title_ text-white text-center sum va_middle" colspan="1">200,000</td>
                <td class="td_title_ text-white text-center" colspan="1"></td>
            </tr>
        </table>
    </div>
</div>