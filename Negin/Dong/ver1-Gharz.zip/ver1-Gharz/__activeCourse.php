<div class="row empty">دوره ها > دوره های فعال > مسافرت جنوب</div>

<div class="cat cat1">
    <div class="box_cat" onclick="page('r','___ratio')">
        <div class="box d-flex mt-2">
            <div class="box_icon"><?php echo $active_course; ?></div>
        </div>
        <div class="box_title">تعیین ضرایب</div>
    </div>
    <div class="box_cat" onclick="page('r','')">
        <div class="box d-flex mt-2">
            <div class="box_icon"><?php echo $active_course; ?></div>
        </div>
        <div class="box_title">دانلود اطلاعات</div>
    </div>
    <div class="box_cat" onclick="page('r','___report')">
        <div class="box d-flex mt-2">
            <div class="box_icon"><?php echo $active_course; ?></div>
        </div>
        <div class="box_title">گزارشات</div>
    </div>
</div>